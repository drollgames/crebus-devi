const crabos = require("./conf.json");
// CrabOS@ultimate-1.0

console.clear()
console.log("------------------------")
console.log("CrabOS Ultimate");
console.log("[INFO]: Iniciando Instância...");
console.log("------------------------");

// suporte => help.crabos.ml

const express = require('express');
const cbos = express();
let error = crabos.error
cbos.use(express.static(__dirname + crabos.publicDir)); // crabos.publicDir
cbos.use(function(req, res, next) {
  res.status(404).send(error);
});
cbos.listen(crabos.port, () => {
  console.log('Servidor iniciado na porta: ' + crabos.port);
  console.log("------------------------");
}); 
